Respected Sir/Madam,
	As per the given the task, I have did my best to achieve. Sending the zip file, for any queries please contact me.
			Thankyou.
			
Yours 
Abhijeet Deokar
abhijeetdeokar74@gmail.com
9822453391


#################################
Please verify the app with the APK also shared in the project.

#################################
Functionality
The app functionality includes a GET Http call which will get a data and needed to be shown on the UI of the app.

#################################
HTTP REQUEST -> https://swapi.dev/api/people/{char_id}

#################################
Additional->
1. Commments will help to know each and every functionality used in the project.
2. Exception handling and crashing of the app is handle with user toasts. 

#################################
Also the app is added on my personal github.

#################################
Major files included are
1. MainActivity.kt
2. AndroidManifest.xml
3. APIinterface.kt
4. RetrofitInstance.kt
5. Character.kt
6. Repository.kt
7. Constants.kt
8. MainViewModel
9. MainViewModelFactory
10. activity_main.xml
11. strings.xml
12. gradle files


Note-->
The project haven't copied from anywhere. 
If wanted you may please verify.

Thankyou. 