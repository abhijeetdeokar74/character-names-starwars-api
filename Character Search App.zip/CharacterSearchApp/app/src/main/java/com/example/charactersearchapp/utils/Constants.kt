package com.example.charactersearchapp.utils

//Basic values needed for use
class Constants {

    companion object {
        //BASE URL which will be needed
        const val BASE_URL = "https://swapi.dev/"

        //MAP function with Key Value Pair
        val options: Map<Int, String> = mapOf(
            0 to "Select a name from dropdown",
            1 to "Luke Skywalker",
            2 to "C-3PO",
            3 to "R2-D2",
            4 to "Darth Vader",
            5 to "Leia Organa",
            6 to "Owen Lars",
            7 to "Beru Whitesun lars",
            8 to "R5-D4",
            9 to "Biggs Darklighter",
            10 to "Obi-Wan Kenobi"
        )

        //Getting Values in ArrayList
        var charactersNamesList = ArrayList(options.values)
    }

    /*
    The Map function is been required as the url was taking paramters in integers and for each integer
    there was a name to be assigned to display to the user for the selection of the dropdown
     */
}