package com.example.charactersearchapp.api

import com.example.charactersearchapp.model.Character
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

//API interface for HTTP methods
interface APIinterface {

    //HTTP GET request method with Path parameter to be passed with the URL
    @GET("api/people/{char_id}")
    suspend fun getCharacter(
        @Path("char_id") number: Int
    ): Response<Character>
}