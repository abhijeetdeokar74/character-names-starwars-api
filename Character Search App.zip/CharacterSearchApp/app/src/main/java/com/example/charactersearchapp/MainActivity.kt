package com.example.charactersearchapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.charactersearchapp.repository.Repository
import com.example.charactersearchapp.utils.Constants.Companion.charactersNamesList
import com.example.charactersearchapp.utils.Constants.Companion.options
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    //late-int : To declare non null Kotlin Variables without initialization
    private lateinit var viewModel: MainViewModel
    private lateinit var option: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        option = enterCharacter as Spinner
        var optionItemSelected = ""

        //Setting Dropdown values from the Map
        option.adapter =
            ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, charactersNamesList)
        option.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            //Dropdown(Spinner) method implementation
            override fun onItemSelected(p0: AdapterView<*>?, view: View?, position: Int, id: Long) {
                for ((key, value) in options) {
                    if (options.get(position).toString() == value) {

                        if (key != 0) {
                            optionItemSelected = (key).toString()
                        } else {
                            optionItemSelected = (0).toString()
                        }
                    }
                }
            }

            //Dropdown(Spinner) method implementation
            override fun onNothingSelected(parent: AdapterView<*>?) {
                Toast.makeText(
                    applicationContext,
                    "Select a character from dropdown.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val repository = Repository()
        val viewModelFactory = MainViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory).get(MainViewModel::class.java)

        //On click of button the action performed
        button.setOnClickListener {

            //Int Value obtained from the dropdown selection
            val myNumber = optionItemSelected

            viewModel.getCharacter(Integer.parseInt(myNumber))

            //Setting the data on UI
            viewModel.myResponse.observe(this, Observer { response ->
                if (response.isSuccessful) {
                    //Logging the response received
                    Log.d("Response received---->", response.body()?.name!!)

                    //Setting data on the xml ids
                    name.text = "Name: " + response.body()?.name
                    birth_year.text = "Birth Year: " + response.body()?.birth_year
                    gender.text = "Gender: " + response.body()?.gender
                    height.text = "Height: " + response.body()?.height
                    mass.text = "Mass: " + response.body()?.mass
                    hair_color.text = "Hair Color: " + response.body()?.hair_color
                    skin_color.text = "Skin Color: " + response.body()?.skin_color
                    eye_color.text = "Eye Color: " + response.body()?.eye_color
                } else {
                    //Logging the error received
                    Log.d("Error received---->", response.errorBody().toString())

                    //Setting error received on the xml ids
                    name.text = "Sorry. No data found!"
                    birth_year.text = response.code().toString()

                    //Also showing a toast to the user
                    Toast.makeText(
                        applicationContext,
                        "Select a character from dropdown.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }
}