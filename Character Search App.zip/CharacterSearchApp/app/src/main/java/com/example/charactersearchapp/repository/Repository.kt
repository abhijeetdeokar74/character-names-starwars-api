package com.example.charactersearchapp.repository

import com.example.charactersearchapp.api.RetrofitInstance
import com.example.charactersearchapp.model.Character
import retrofit2.Response

//Exposing the data got from the retrofit to the app
class Repository {

    suspend fun getCharacter(number: Int): Response<Character> {
        return RetrofitInstance.api.getCharacter(number)
    }
}