package com.example.charactersearchapp

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.charactersearchapp.model.Character
import com.example.charactersearchapp.repository.Repository
import kotlinx.coroutines.launch
import retrofit2.Response

class MainViewModel(private val repository: Repository) : ViewModel() {

    //Method for setting the data on UI as per the User Action
    val myResponse: MutableLiveData<Response<Character>> = MutableLiveData()

    //Calling the repository method to set the data for UI
    fun getCharacter(number: Int) {
        viewModelScope.launch {
            val response = repository.getCharacter(number)
            myResponse.value = response
        }
    }
}