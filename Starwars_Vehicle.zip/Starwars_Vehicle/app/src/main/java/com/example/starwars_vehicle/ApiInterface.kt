package com.example.starwars_vehicle

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiInterface {

    @GET("api/vehicles")
    fun getVehicles(): Call<VehiclesData>

    @GET("api/vehicles/{vn}")
    fun getVehicles2(
        @Path("vn") number: Int
    ): Call<VehiclesData>
}