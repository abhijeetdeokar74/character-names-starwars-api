package com.example.starwars_vehicle

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.row_items.view.*

class Adapter(val context: Context, val vehicle: VehiclesData) :
    RecyclerView.Adapter<Adapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var name: TextView
        var vehicle_class: TextView
        var model: TextView

        init {
            name = itemView.name
            vehicle_class = itemView.vehicle_class
            model = itemView.model
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var itemView = LayoutInflater.from(context).inflate(R.layout.row_items, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.name.text = vehicle.results.get(position).name
        holder.vehicle_class.text = vehicle.results.get(position).vehicle_class
        holder.model.text = vehicle.results.get(position).model
    }

    override fun getItemCount(): Int {
        return vehicle.results.size
    }
}