package com.example.starwars_vehicle

data class VehiclesData(
    val count: Int,
    val next: String,
    val previous: Any,
    val results: List<Vehicle>
)