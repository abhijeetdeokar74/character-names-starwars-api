package com.example.starwars_vehicle

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    val BASE_URL = "https://swapi.dev/"

    lateinit var adapter: Adapter
    lateinit var linearLayoutManager: LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerview_vehicles.setHasFixedSize(true)
        linearLayoutManager = LinearLayoutManager(this)

        recyclerview_vehicles.layoutManager = linearLayoutManager
        getvehiclesData()
    }

    private fun getvehiclesData() {
        val retrofitBuilder = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(BASE_URL)
            .build()
            .create(ApiInterface::class.java)

        val retrofitData = retrofitBuilder.getVehicles()

        retrofitData.enqueue(object : Callback<VehiclesData?> {
            override fun onResponse(call: Call<VehiclesData?>, response: Response<VehiclesData?>) {
                val resonseBody = response.body()!!

                adapter = Adapter(baseContext, resonseBody)
                adapter.notifyDataSetChanged()
                recyclerview_vehicles.adapter = adapter
            }

            override fun onFailure(call: Call<VehiclesData?>, t: Throwable) {
                Log.d("MainActivity", "onFailure: " + t.message)
            }
        })
    }
}